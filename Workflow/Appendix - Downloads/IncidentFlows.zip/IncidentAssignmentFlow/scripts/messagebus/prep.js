$.context.request = {
	name: "DJ",
	number: 42
};